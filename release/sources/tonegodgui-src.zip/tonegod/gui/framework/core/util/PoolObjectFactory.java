package tonegod.gui.framework.core.util;

/**
 *
 * @author t0neg0d
 */
public interface PoolObjectFactory<T> {
	public T newPoolObject();
}
